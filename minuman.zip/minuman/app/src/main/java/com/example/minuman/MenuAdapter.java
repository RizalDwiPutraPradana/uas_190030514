package com.example.minuman;

import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.Recylerview;

import java.util.ArrayList;

public  class MenuAdapter extends RecylerView.Adapter<MenuAdapter.MenuViewHolder> {
      private Context context;
      private ArrayList<menu> menuminuman;

      public MenuAdapter(Context mcontext, ArrayList<menu> menuminuman) {
          context = mcontext;
          menu = menuminuman;


          @NonNull
          @Override
          public menuviewholder oncreateviewholder(@NonNull ViewGroup parent, int viewtype){
              view v = LayoutInflater.from(context).inflate(R.layout.item_menu,parent, : false);

              return new menuviewholder(v);
          }

          @Override
          public void  oncreateviewholder(@NonNull menuviewholder holder, int position){
              menu listbaru = menus.get(position);
              string gambarbaru = listbaru.getGambar();
              string harga = listbaru.getHarga();
              string nama = listbaru.getNama();

              holder.tvnamadata.setText(nama);
              holder.tvhargadata.setText(harga);
              Glide
                      .with(context)
                      .load(gambarbaru)
                      .centerCrop()
                      .into(holder.imdata);
          }

          @override
           public int getitemCout() {
              return menus.size();
          }
          public class MenuViewHolder extends RecylerView.ViewHolder {
              public ImageView imdata;
              public TextView twharga;
              public TextView twnamadata;

              public MenuViewHolder(@NonNull View ItemView) {
                  super(ItemView);
              }










